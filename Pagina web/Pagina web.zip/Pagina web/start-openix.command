#!/bin/bash
cd "$(dirname "$0")"
PORT=8080
URL="http://127.0.0.1:${PORT}/index.html"
echo ""
echo "  Openix — servidor local"
echo "  Abre: $URL"
echo "  Pulsa Ctrl+C para parar"
echo ""
if command -v open >/dev/null 2>&1; then
  open "$URL" 2>/dev/null || true
fi
exec python3 -m http.server "$PORT"
