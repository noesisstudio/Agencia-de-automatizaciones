/** Carga la facturación de servicios Openix (facturas emitidas a clientes y sus pagos). */
(function () {
  function emptyProfile(username) {
    return {
      company: { displayName: username || "Cliente", plan: "", nif: "" },
      contract: { status: "none", label: "Sin contrato activo", nextInvoiceDate: null },
      invoices: [],
      payments: [],
      serviceStatus: [],
    };
  }

  function dataPath(username) {
    var base =
      (window.OPENIX && window.OPENIX.billingDataBase) || "data/client-billing";
    return (
      String(base).replace(/\/$/, "") +
      "/" +
      encodeURIComponent(String(username || "").toLowerCase()) +
      ".json"
    );
  }

  function cacheKey(username) {
    return "openix_billing_" + String(username || "").toLowerCase();
  }

  function readCache(username) {
    try {
      var raw = localStorage.getItem(cacheKey(username));
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function writeCache(username, data) {
    try {
      localStorage.setItem(cacheKey(username), JSON.stringify(data));
    } catch (e) {
      /* ignore */
    }
  }

  window.OpenixBilling = {
    load: async function (username) {
      if (!username) return emptyProfile("");

      if (location.protocol === "file:") {
        var cached = readCache(username);
        return cached || emptyProfile(username);
      }

      try {
        var r = await fetch(dataPath(username), { cache: "no-store" });
        if (!r.ok) {
          var fallback = readCache(username);
          return fallback || emptyProfile(username);
        }
        var data = await r.json();
        writeCache(username, data);
        return data;
      } catch (e) {
        var cached2 = readCache(username);
        return cached2 || emptyProfile(username);
      }
    },
    emptyProfile: emptyProfile,
  };
})();
