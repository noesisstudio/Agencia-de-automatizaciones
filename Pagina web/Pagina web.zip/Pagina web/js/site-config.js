window.OPENIX = {
  chatApiBaseUrl: "",
  chatTenantId: "openix",
  /** Ruta base de los JSON de facturación por cliente (facturas y pagos de servicios Openix). */
  billingDataBase: "data/client-billing",
  demoLogin: {
    username: "prueba",
    password: "prueba",
  },
};
