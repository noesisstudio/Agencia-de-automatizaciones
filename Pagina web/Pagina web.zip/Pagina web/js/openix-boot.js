/**
 * Respaldo: carga css/styles.css si la página no lleva estilos incrustados.
 */
(function () {
  "use strict";

  if (document.getElementById("openix-styles-inline")) {
    return;
  }

  var docHref = location.href.split("#")[0].split("?")[0];
  var pageBase = docHref.endsWith("/")
    ? docHref
    : docHref.slice(0, docHref.lastIndexOf("/") + 1);

  var link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = new URL("css/styles.css", pageBase).href;
  link.id = "site-css";
  document.head.appendChild(link);
})();
