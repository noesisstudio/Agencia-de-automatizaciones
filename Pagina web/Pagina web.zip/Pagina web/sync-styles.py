#!/usr/bin/env python3
"""Copia css/styles.css al bloque <style id=\"openix-styles-inline\"> de cada .html."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSS = (ROOT / "css/styles.css").read_text(encoding="utf-8")
FONT_LINE = (
    '  <link href="https://fonts.googleapis.com/css2?'
    "family=Figtree:wght@400;500;600&family=Outfit:wght@500;600;700;800&display=swap"
    '" rel="stylesheet" />\n'
)
STYLE_BLOCK = "<style id=\"openix-styles-inline\">\n" + CSS + "\n</style>"
EXTERNAL = '  <link rel="stylesheet" href="css/styles.css" id="site-css" />\n'
FONT_RE = re.compile(
    r'  <link href="https://fonts\.googleapis\.com/css2\?[^"]+" rel="stylesheet" />\n'
)

for path in sorted(ROOT.glob("*.html")):
    html = path.read_text(encoding="utf-8")
    html = FONT_RE.sub(FONT_LINE, html, count=1)
    start = html.find('<style id="openix-styles-inline">')
    if start == -1:
        print("skip:", path.name)
        continue
    end = html.find("</style>", start) + len("</style>")
    html = html[:start] + STYLE_BLOCK + html[end:]
    if 'id="site-css"' not in html:
        html = html.replace("</style>\n", "</style>\n" + EXTERNAL, 1)
    path.write_text(html, encoding="utf-8")
    print("ok", path.name)

print("Listo.")
